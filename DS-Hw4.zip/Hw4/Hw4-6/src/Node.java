
public class Node {

    Object item;
    Node next;
    
    public Node(Object i , Node n){
        item = i;
        next = n;
    }
}

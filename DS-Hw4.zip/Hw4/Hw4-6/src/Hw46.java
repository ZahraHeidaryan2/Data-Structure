
public class Hw46 {

    public static void main(String[] args) throws Exception {

        LinkedList ll = new LinkedList();

        ll.add(12);
        ll.add(25);
        ll.add(62);
        ll.add(79);


        ll.delete(2,1);

        System.out.println(ll.toString());
        
    }

    

}

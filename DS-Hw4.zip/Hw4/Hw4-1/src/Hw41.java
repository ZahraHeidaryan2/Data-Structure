
public class Hw41 {

    public static void main(String[] args) throws Exception{

        System.out.println("output:");
        Stack stack = new Stack();
        
        stack.push(3);
        stack.push(4);
        
        System.out.println(stack.size());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
        
        
        System.out.println("output:");
        Queue queue = new Queue();
        
        queue.EnQueue(1);
        queue.EnQueue(2);
        queue.EnQueue(3);
        
        System.out.println(queue.size());
        System.out.println(queue.DeQueue());
        System.out.println(queue.DeQueue());
        System.out.println(queue.DeQueue());
        
    }
    
}

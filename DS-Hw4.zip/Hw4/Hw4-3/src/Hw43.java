
public class Hw43 {

    public static void main(String[] args) throws Exception{


        
            LinkedList sl = new LinkedList();

            sl.add(0, 1);
            sl.add(1, 2);
            sl.add(2, 3);
            sl.add(3, 4);
            sl.add(4, 5);
            sl.add(5, 6);

            sl.swap(4, 1);
            
            System.out.println(sl.get(2));
            System.out.println(sl.get(5));
            
        
    }
    
}

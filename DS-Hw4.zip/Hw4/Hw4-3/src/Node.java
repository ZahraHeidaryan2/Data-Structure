
public class Node {
    
    Object item;
    Node next;
    
    public Node(Object o , Node n){
        item = o;
        next = n;
    }
    
}

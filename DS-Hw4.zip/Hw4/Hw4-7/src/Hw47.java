

public class Hw47 {

    public static void main(String[] args) throws Exception{


            LinkedList ll = new LinkedList();

            ll.add(12);
            ll.add(21);
            ll.add(38);
            ll.add(43);
            ll.add(97);

            System.out.println("Middle : " +Middle(ll));

    }

    public static Object Middle(LinkedList ll) throws Exception {

        if (ll.size() < 1) {
            throw new Exception("List is null!");
        }

        Object o = null;
        int i;
        if (ll.size() % 2 == 0) {
            i = ll.size() / 2;
            Node n = ll.getNode(0);
            while (n != null) {
                if (i == 1) {
                    o = n.item;
                }
                i--;
                n = n.next;
            }

        } else {

            i = (ll.size() / 2) + 1;
            Node n = ll.getNode(0);
            while (n != null) {
                if (i == 1) {
                    o = n.item;
                }
                i--;
                n = n.next;
            }
        }

        return o;
    }

}


public class Hw45 {

    public static void main(String[] args) {

        DLinkedList dll = new DLinkedList();
        
        dll.add(48);
        dll.add("dcal");
        dll.add(39);
        dll.add("sbfjd");
        
        
        
        
        System.out.println(dll.toString());
    }
    
}


public class DLinkedList {

    private Node head;
    private Node tail;
    private int count;

    public DLinkedList() {
        head = new Node(null, null, tail);
        tail = new Node(null, head, null);
        count = 0;
    }

    
    public void add(Object o) {
        Node n = new Node(o, null, null);
        Node nNode = tail.prev;
        tail.prev = n;
        n.next = tail;
        nNode.next = n;
        n.prev = nNode;
        count++;
    }

    public Object removeFirst() {
        Node n = null;
        if (count >= 1) {
            n = head.next;
            head.next = n.next;
            n.next.prev = head;
            count--;
        }
        return n.item;
    }

    public Object removeLast() {
        Node n = null;
        if (count >= 1) {
            n = tail.prev;
            tail.prev = n.prev;
            n.prev.next = tail;
            count--;
        }
        return n.item;
    }

    public int size() {
        return count;
    }

    

    @Override
    public String toString(){
        
        String str = "";
        Node n1 = head.next;
        while(n1 != tail){
            Node n2 = head.next;
            while(n2 != tail){
                if(n1.item.getClass() == Integer.class && n2.item.getClass() == Integer.class){
                    if((int)n1.item + (int)n2.item == 87){
                        str += n1.item + " ";
                    }
                }
                n2 = n2.next;
            }
            n1 = n1.next;
        }        
        
        return str;
    }
    
    
    
}
